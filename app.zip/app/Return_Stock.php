<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Return_Stock extends Model
{
    //
    protected $table = 'return_stock';
}
