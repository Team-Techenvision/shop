<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DeWallet extends Model
{
    //
    protected $table = 'de_wallets';
}
