$(function() {
  'use strict';

  $("exampleDropzone").dropzone({
    url: 'nobleui.com'
  });
});