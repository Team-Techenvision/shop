<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class shop_stock extends Model
{
    //
    protected $table = 'shop_stocks';
}
