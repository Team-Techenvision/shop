
<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h6 class="card-title"><?php echo e($page_title); ?></h6>
        <div class="any_message">
              <?php if(session()->has('alert-danger')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session()->get('alert-danger')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(session()->has('alert-success')): ?>
                  <div class="alert alert-success">
                      <?php echo e(session()->get('alert-success')); ?>

                  </div>
              <?php endif; ?>
         </div>     
        <!-- <p class="card-description">Read the <a href="https://datatables.net/" target="_blank"> Official DataTables Documentation </a>for a full list of instructions and other options.</p> -->
        <div class="table-responsive">
          <table id="dataTableExample" class="table">
          <thead>     
              <tr>
                <th>Sr. No.</th> 
                <th>First Name</th> 
                <!-- <th>Last Name</th> -->
                <th>Email</th>  
                <th>Phone</th>
                <th>User Id</th> 
                <!-- <th>Password</th> -->
                <th>Change Status</th>                  
              </tr>
            </thead>
            <tbody>
            <?php $i = 1; ?>            
            <?php $__currentLoopData = $shop_Employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th><?php echo $i; ?></th> 
                <th><?php echo e($row->name); ?></th>
                <!-- <th><?php echo e($row->name); ?></th>    -->
                <th><?php echo e($row->email); ?></th>               
                <th><?php echo e($row->phone); ?></th>
                <th><?php echo e($row->phone); ?></th> 
                <!-- <th><?php echo e($row->password); ?></th>  -->
                  <th>                         
                   <form action="<?php echo e(url('change-status')); ?>" method="post" >
                   <?php echo csrf_field(); ?>
                   <div>
                      <input type="hidden" name="emp_id" value="<?php echo e($row->id); ?>" />
                      <input type="hidden" name="emp_isblock" value="<?php echo e($row->is_block); ?>" />
                      <?php if($row->role != 1) {?>
                      <?php if($row->is_block != "0"){ ?>
                        <button type="submit" class="btn btn-danger" >Active</button>
                        
                    <?php }else{?>  <button type="submit" class="btn btn-primary" >InActive</button> <?php } } else {?>
                      <button type="submit" class="btn btn-warning" disabled>Admin</button>
                    <?php } ?>  
                     
                 
                      </div>
                      </form>
                    </th>                 
                </tr>
                <?php $i++; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>             
              </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
      <script>
      $(document).ready(function()
      {
        $('.any_message').fadeOut(5500);
      });
         
      </script>    <?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/components/view_shopEmp.blade.php ENDPATH**/ ?>