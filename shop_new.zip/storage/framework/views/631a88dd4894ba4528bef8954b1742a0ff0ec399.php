<div class="col-md-12"> 
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title"><?php echo e($page_title); ?></h3>	
                        <form action="<?php echo e(url('submit-employee')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                            <div class="box-body">
                            <div class="row">
                                <div class="col-md-6 m-auto">
                                    <div class="form-group">
                                        <label>Employee Name</label>
                                        <input type="text" class="form-control" name="emp_name" required>                                     
                                    </div>                                   
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" class="form-control" name="email">                                     
                                    </div>
                                    <div class="form-group">
                                        <label>Phone No</label>
                                        <input type="text" class="form-control" name="phone_no" minlength="10" maxlength="10" required>                                     
                                    </div>
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="text" class="form-control" name="password" maxlength="8" value="12345" readonly>                                     
                                    </div>
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-primary mr-2">
                                        <input type="reset" class="btn btn-light">                            
                                    </div>
                                    <div class="any_message">
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(session()->has('alert-danger')): ?>
                                        <div class="alert alert-danger">
                                            <?php echo e(session()->get('alert-danger')); ?>

                                        </div>
                                    <?php endif; ?>
                                        <?php if(session()->has('alert-success')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session()->get('alert-success')); ?>

                                        </div>
                                    <?php endif; ?>
                                  </div> 
                                </div>                              
                            </div> 
                          </div>  
                        </form>		
                    </div> 
                </div>    
            </div>
            
            
    <?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/components/add_shop_Employee.blade.php ENDPATH**/ ?>