




<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h6 class="card-title"><?php echo e($page_title); ?></h6>
        <form action="<?php echo e(url('product-order')); ?>" method="post">
        <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-sm-12">
                  <div class="form-group">
                    <label class="control-label">Product</label>
                    <select name="product_name" id="product_id" class="form-control rounded" required>
                    <option value="">Select Product</option>
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($row->products_id); ?>"><?php echo e($row->product_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                   
                    </select>
                  </div>
              </div><!-- Col --> 
            </div>               
                <div class="row">
                  <div class="col-sm-4">                  
                    <div class="form-group">
                      <label class="control-label">Quantity</label>
                      <input type="number" class="form-control text-center" name="p_qty" id="productqty" value="1" min="1" required>
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="form-group">
                      <label class="control-label">Expiry Date</label>
                      <input type="date" class="form-control" name="exp_date">
                    </div>
                  </div>                 
                </div>           
              <div class="row">
              <div class="col-sm-6">
                  <div class="form-group">
                  <button class="btn btn-primary mr-1" type="submit">Add Quantity</button>
                  <button class="btn btn-light" type="reset">Reset</button>
                  <div class="any_message mt-3">
                      <?php if(count($errors) > 0): ?>
                        <div class = "alert alert-danger">
                            <ul>
                              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($error); ?></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                      <?php endif; ?>                   
                    <?php if(session()->has('alert-danger')): ?>
                      <div class="alert alert-danger">
                          <?php echo e(session()->get('alert-danger')); ?>

                      </div>
                    <?php endif; ?>
                    <?php if(session()->has('alert-success')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session()->get('alert-success')); ?>

                      </div>
                    <?php endif; ?>
                  </div> 
              </div><!-- Col --> 
            </div> 
          </form>            
      </div>
    </div>
  </div>
</div>

<?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/components/admin_add_stock.blade.php ENDPATH**/ ?>