<div class="col-md-8 m-auto"> 
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title text-center"><?php echo e($page_title); ?></h3>	
                        <form action="<?php echo e(url('submit-Password')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                            <div class="box-body">
                            <div class="row">
                                <div class="col-md-6 m-auto">
                                    <div class="form-group">
                                        <label>Old Password</label>
                                        <input type="password" class="form-control" name="old_pass" required>                                     
                                    </div>                                    
                                    <div class="form-group">
                                        <label>New Password</label>
                                        <input type="password" class="form-control" name="new_pass" minlength="5" maxlength="10" required>                                     
                                    </div>
                                    <div class="form-group">
                                        <label>Confirm Password</label>
                                        <input type="password" class="form-control" name="confirm_pass" minlength="5" maxlength="10" required>                                     
                                    </div>                                    
                                    <div class="form-group">
                                        <input type="submit" class="btn btn-primary mr-2">
                                        <input type="reset" class="btn btn-light">                            
                                    </div>
                                    <div class="any_message">
                                    <?php if($errors->any()): ?>
                                        <div class="alert alert-danger">
                                            <ul>
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    <?php endif; ?>
                                    <?php if(session()->has('alert-danger')): ?>
                                        <div class="alert alert-danger">
                                            <?php echo e(session()->get('alert-danger')); ?>

                                        </div>
                                    <?php endif; ?>
                                        <?php if(session()->has('alert-success')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session()->get('alert-success')); ?>

                                        </div>
                                    <?php endif; ?>
                                  </div> 
                                </div> 
                                </div> 
                          </div>  
                        </form>		
                    </div> 
                </div>    
            </div>
            
            
    <?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/components/change_password.blade.php ENDPATH**/ ?>