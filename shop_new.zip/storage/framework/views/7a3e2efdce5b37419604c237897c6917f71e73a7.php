<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h6 class="card-title"><?php echo e($page_title); ?></h6>
        <div class="any_message mt-2">
          <?php if(session()->has('message_success')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message_success')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>

          <?php if(session()->has('message')): ?>
            <div class="alert alert-danger">
                <?php echo e(session()->get('message')); ?>

              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
          <?php endif; ?>
        </div>
      <form action="<?php echo e(url('search-product-barcode')); ?>" method="post"> 
      <?php echo csrf_field(); ?>    
        <div class="row">        
          <div class="col-sm-2 text-right">                           
            <div class="form-group p-2">             
            <label for="contact">Barcode :-</label>                      
            </div>
          </div>
          <div class="col-sm-4">                           
            <div class="form-group">             
              <input type="text" class="form-control" name="barcode"  id="barcode" minlength="4" maxlength="15" placeholder="Barcode" required>               
            </div>
          </div>
          <div class="col-sm-4">                  
            <div class="form-group"> 
            <input type="submit" id="add_customer"  class="btn btn-primary" value="Submit" > 
              <!-- <button name="submit"  id="add_customer" onclick="add_customer()" class="btn btn-primary">Submit</button>              -->
            </div>
          </div>       
      </div>
    </form> 

    <?php if(isset($stock)): ?>
    <form action="<?php echo e(url('return-product-submit')); ?>" method="post">
    <?php echo csrf_field(); ?>  
        <div class="row mt-5">
                <div class="col-sm-4">                  
                    <div class="form-group">
                      <label class="control-label">Product Name</label>
                      <!-- < ?php print_r($stock);die(); ?> -->
                       <?php if(!$stock[0]->size_name): ?>
                      <input type="text" class="form-control text-center" name="product_name" value="<?php echo e($stock[0]->product_name); ?>" id="product_name" readonly>
                       <?php else: ?>                      
                          <input type="text" class="form-control text-center" name="product_name" value="<?php echo e($stock[0]->product_name); ?> (<?php echo e($stock[0]->size_name); ?>)" id="product_name" readonly>
                       <?php endif; ?>
                    </div>
                  </div>

                  <div class="col-sm-4">                  
                    <div class="form-group">
                      <label class="control-label">Available Quantity</label>                      
                      <input type="text" class="form-control text-center" name="avl_quantity" value="<?php echo e($stock[0]->avl_quantity); ?>" id="avl_quantity" readonly>
                    </div>
                  </div>
                  <div class="col-sm-4">                  
                    <div class="form-group">
                      <label class="control-label">Return Quantity</label>
                      <input type="number" class="form-control text-center" name="return_quantity" id="return_quantity" value="1" min="1" required>
                    </div>
                  </div>
            </div>

            <input type="hidden" name="id" value="<?php echo e($stock[0]->id); ?>">
            <?php $shop_id = Auth::user()->shop_id; ?>
            <input type="hidden" name="shop_id" value="<?php echo e($shop_id); ?>">
            <input type="hidden" name="products_id" value="<?php echo e($stock[0]->products_id); ?>">
            
            <div class="row">
              <div class="col-sm-6">
                  <div class="form-group">
                  <button class="btn btn-primary mr-1" type="submit">Return Quantity</button>
                  </div>
                </div>
            </div>        
    </form>

    <?php endif; ?>
  <div class="any_message mt-3">  
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
          <ul>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($error); ?></li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </div>
    <?php endif; ?>
  </div>

    </div>
  </div>
</div>




<?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/components/return_stock.blade.php ENDPATH**/ ?>