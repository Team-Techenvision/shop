
<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h6 class="card-title"><?php echo e($page_title); ?></h6>       
        <div class="table-responsive">
          <table id="dataTableExample" class="table">
          <thead>     
              <tr>
                <th>Sr. No.</th>
                <!-- <th>Barcode</th>   -->
                <th>Date</th>
                <th>Sell Total Amount</th>                                
                <!-- <th>Send Mail</th>        -->
              </tr>
            </thead>
            <tbody> 
            <?php 
              $count = 1;  

              ?> 
              <?php $__currentLoopData = $daily_report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
            <tr> 
            <td> <?php echo e($count++); ?> </td> 
            <td><?php echo e($r->Date); ?></td> 
            <td><?php echo e(number_format($r->tatal_amount, 2)); ?></td>
            <!-- <td><a href="<?php echo e(url('daily-sell-update/'.$r->Date)); ?>" class="btn btn-info">Send</a></td>             -->
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div><?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/components/daily_sell_report.blade.php ENDPATH**/ ?>