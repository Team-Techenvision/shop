

<?php $__env->startSection('content'); ?>
<html>
<head>
<style>
	table td, table th{
		border:1px solid black;
	}
</style>
</head>
<body>
<div class="container">


<br/>
<!-- <a href="#">Download PDF</a> -->


<table>
    <tr>
        <th>Product</th>
        <th>Price</th>
        <th>Product Code</th>
    </tr>
    
     
</table>
</div>
</body>
</html>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/webviews/order_pdf.blade.php ENDPATH**/ ?>