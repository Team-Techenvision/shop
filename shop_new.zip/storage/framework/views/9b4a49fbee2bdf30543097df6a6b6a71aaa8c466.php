
<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h6 class="card-title"><?php echo e($page_title); ?></h6>
        <!-- <p class="card-description">Read the <a href="https://datatables.net/" target="_blank"> Official DataTables Documentation </a>for a full list of instructions and other options.</p> -->
        <!-- <form action="<?php echo e(url('check-expiry')); ?>" method="post">
        <?php echo csrf_field(); ?> 
              <div class="row m-auto">
                <div class="col-sm-8  text-right">
                  <div class="form-group">
                    <label class="control-label">Filter</label>
                    <select name="Exp_date" id="Exp_date" class="form-control rounded" required>
                      <option value="">Select Day</option>                   
                      <option value="5">5 Day</option>
                      <option value="15">15 Day</option>
                      <option value="30">1 Month</option>
                      <option value="60">2 Month</option>
                      <option value="180">6 Month</option>
                    </select>                   
                  </div>                         
                </div><! -- Col - ->
              <div  class="col-sm-4 text-left"> 
              <! -- <button type="submit" name="search" class="btn btn-info mt-4">Search</button>            -- >
                <input type="submit" name="search" value="search" class="btn btn-info mt-4" >
              </div>  
            </div>
        </form> -->
        <div class="table-responsive">
          <table id="dataTableExample" class="table">
          <thead>     
              <tr>
                <th>Sr. No.</th> 
                <th>Product Name</th> 
                <th>Quantity</th>
                <th>Available Quantity</th>  
                <th>Expiry Date</th>    
                <th>Print Barcode</th>             
              </tr>
            </thead>
            <tbody> 
            <?php 
              $count = 1;  

              ?> 
              <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
            <tr> 
            <td> <?php echo e($count++); ?> </td>
            <?php if($r->size_name): ?>
            <td><?php echo e($r->product_name); ?> (<?php echo e($r->size_name); ?>)</td>
            <?php else: ?>
              <td><?php echo e($r->product_name); ?></td>
            <?php endif; ?>           
            <td><?php echo e($r->input_quantity); ?></td>
            <td><?php echo e($r->avl_quantity); ?></td>
            <td><?php echo e($r->expiry_date); ?></td> 
           <?php  $no = strlen($r->barcode);
                if($no ==10)
                { ?>
                  <td> <a href="<?php echo e(url('generate-barcode/'.$r->barcode)); ?>"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-printer"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg> </a> </td>
              <?  }else{ ?> <td></td> <?php  } ?>
               
            <!-- <td> <a href="<?php echo e(url('generate-barcode/'.$r->barcode)); ?>"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-printer"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg> </a> </td>    -->
            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div><?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/components/admin_view_stock.blade.php ENDPATH**/ ?>