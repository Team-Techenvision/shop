<div class="row">
  <div class="col-md-12 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h6 class="card-title">Print Barcode</h6>
        <form action="<?php echo e(url('print-barcode')); ?>" method="post">
        <?php echo csrf_field(); ?>
            <div class="row">
              <div class="col-sm-12">
              <div class="form-group">
                      <label class="control-label">Enter Quantity</label>
                      <input type="number" class="form-control" name="quantity" value="" required>
                      <input type="text" class="" name="barcode" value="<?php echo e($barcode); ?>">
                    </div>
                    <button type="submit">Submit</button>
              </div><!-- Col --> 
            </div>               
                      
              
          </form>            
      </div>
    </div>
  </div>
</div><?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/common/print.blade.php ENDPATH**/ ?>