
<?php $__env->startPush('plugin-styles'); ?>
  <link href="<?php echo e(asset('assets/plugins/datatables-net/dataTables.bootstrap4.css')); ?>" rel="stylesheet" />
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div>
<nav class="page-breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="#"><?php echo e($main_breadcrum); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page"><?php echo e($page_title); ?></li>
  </ol>
</nav>
            <?php if($flag == 1): ?>
            	<?php echo $__env->make('admin.components/admin_view_stock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($flag == 2): ?>
            	<?php echo $__env->make('admin.components/admin_add_stock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($flag == 3): ?>
            	<?php echo $__env->make('admin.components/admin_edit_stock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($flag == 4): ?>
            <?php echo $__env->make('admin.components/admin_update_stock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($flag == 5): ?>
            	<?php echo $__env->make('admin.components/admin_delete_stock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($flag == 6): ?>
            	<?php echo $__env->make('admin.components/admin_customer_order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($flag == 7): ?>
            <?php echo $__env->make('admin.components/add_cust_br_order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>            	
            <?php elseif($flag == 8): ?>
            	<?php echo $__env->make('admin.components/view_order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            <?php elseif($flag == 9): ?>
            	<?php echo $__env->make('admin.components/view_shopEmp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  
            <?php elseif($flag == 10): ?>
            	<?php echo $__env->make('admin.components/add_shop_Employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($flag == 11): ?>
            	<?php echo $__env->make('admin.components/cust_order_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
            <?php elseif($flag == 12): ?>
            	<?php echo $__env->make('admin.components/print_product_barcode', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif($flag == 13): ?>
            	<?php echo $__env->make('admin.components/order_detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- <?php elseif($flag == 14): ?>
            	<?php echo $__env->make('admin.components/show_total_stock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>          -->
            <!-- <?php elseif($flag == 15): ?>
            	<?php echo $__env->make('admin.components/return_stock', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->
            <!-- <?php elseif($flag == 16): ?>
            	<?php echo $__env->make('admin.components/daily_sell', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                         -->
            <?php endif; ?>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
  <script src="<?php echo e(asset('assets/plugins/datatables-net/jquery.dataTables.js')); ?>"></script>
  <script src="<?php echo e(asset('assets/plugins/datatables-net-bs4/dataTables.bootstrap4.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
  <script src="<?php echo e(asset('assets/js/data-table.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/webviews/admin_manage_stock.blade.php ENDPATH**/ ?>