 
<?php 

 for($i=0; $i<$quantity; $i++){ 
     ?>
<?php echo $barcode_data; ?>

<br><br>
<?php }
?>
 <script type="text/javascript">
      window.onload = function() { window.print(); }
 </script><?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/common/barcode.blade.php ENDPATH**/ ?>