




<div class="row">
  <div class="col-md-6 grid-margin stretch-card">
    <div class="card">
      <div class="card-body">
        <h6 class="card-title"><?php echo e($page_title); ?></h6>
        <div class="form-group">
            <label> Name</label>
            <input type="text" class="form-control" value="<?php echo e($user->name); ?>" readonly>                                     
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="text" class="form-control" value="<?php echo e($user->email); ?>" readonly>                                     
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="text" class="form-control" value="<?php echo e($user->phone); ?>" readonly>                                     
        </div>
        <div class="form-group">
            <label>Login ID</label>
            <input type="text" class="form-control" value="<?php echo e($user->phone); ?>" readonly>                                     
        </div>               
      </div>
    </div>
  </div>
  <div class="col-md-6 grid-margin stretch-card">  
    <div class="card">
      <div class="card-body">
      <div class="d-flex justify-content-between">
            <h6 class="card-title"><?php echo e($page_title); ?></h6>           
            <a href="#demo" class="btn btn-primary" data-toggle="collapse">Edit Profile</a>
        </div> 
        <div id="demo" class="collapse">
            <!-- <div class="card card-body"> -->
            <form action="<?php echo e(url('update-profile')); ?>" method="post">
                <?php echo csrf_field(); ?>
                    <div class="box-body">
                    <div class="row">
                        <div class="col-md-12 m-auto">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" class="form-control" name="emp_name" value="<?php echo e($user->name); ?>" required>                                     
                            </div>                                  
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control" name="email" value="<?php echo e($user->email); ?>" required>                                     
                            </div>
                            <div class="form-group">
                                <label>Phone No</label>
                                <input type="text" class="form-control" name="phone_no" value="<?php echo e($user->phone); ?>" minlength="10" maxlength="10" required>                                     
                            </div>
                            <div class="form-group">
                            <div class="alert alert-warning">
                                <strong>Phone No.</strong> is a your Login Id.
                            </div>                                                                  
                            </div>                                   
                            <div class="form-group">
                                <input type="submit" class="btn btn-danger mr-2" value="Update">
                                <!-- <a href="#demo" class="btn btn-light" data-toggle="collapse">Close</a>                                                                    -->
                                <input type="reset" name="reset" class="btn btn-light" >
                            </div>                     
                        </div>
                        </div> 
                    </div>  
                </form>	 
            <!-- </div> -->
        </div> 
        <div class="any_message">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <?php if(session()->has('alert-danger')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('alert-danger')); ?>

                </div>
            <?php endif; ?>
            <?php if(session()->has('alert-success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('alert-success')); ?>

                </div>
            <?php endif; ?>
        </div>                
      </div>
    </div>
  </div>
</div>

<?php /**PATH E:\xamp\htdocs\shop\resources\views/admin/components/profile_page.blade.php ENDPATH**/ ?>