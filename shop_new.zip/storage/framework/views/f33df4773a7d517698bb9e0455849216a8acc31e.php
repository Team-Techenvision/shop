<html>
<head>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style type="text/css">
	table td, table th{
		border:1px solid black;
	}
</style>
</head>
<body>
<div class="container">


<br/>
<!-- <a href="#">Download PDF</a> -->


<table>
    <tr>
        <th>Product</th>
        <th>Price</th>
        <th>Product Code</th>
    </tr>
     
</table>
</div>
</body>
</html><?php /**PATH E:\xamp\htdocs\shop\resources\views/invoice.blade.php ENDPATH**/ ?>